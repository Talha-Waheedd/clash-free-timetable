
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri"]
SLOTS = ["9:00–10:15", "10:30–11:45", "12:00–1:15", "2:15–3:30", "3:45–5:00"]

def generate_all_slots():
    return [(day, slot) for day in DAYS for slot in SLOTS]
