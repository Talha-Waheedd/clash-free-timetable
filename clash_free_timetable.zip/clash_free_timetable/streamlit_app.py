
import streamlit as st
from models import *
from data_manager import DataManager
from scheduler import TimetableScheduler
from timetable_formatter import timetable_to_dataframe

st.title("📅 Clash-Free Timetable Generator")

dm = DataManager()
choice = st.radio("Use existing data?", ["Yes", "No"])

if choice == "Yes":
    try:
        dm.load()
        st.success("Loaded data.json")
    except:
        st.error("data.json not found. Please set up your data.")
else:
    st.warning("Add your batch/teacher setup logic here or manually define in code.")
    # Add setup logic from your own definition step

if st.button("Generate Timetable"):
    scheduler = TimetableScheduler(dm)
    scheduler.create_schedule()
    df = timetable_to_dataframe(scheduler.schedule)
    st.dataframe(df.style.set_properties(**{'white-space': 'pre-wrap'}))
