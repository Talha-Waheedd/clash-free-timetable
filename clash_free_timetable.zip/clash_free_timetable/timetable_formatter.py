
import pandas as pd
from schedule_config import DAYS, SLOTS

def timetable_to_dataframe(schedule):
    df = pd.DataFrame(index=DAYS, columns=SLOTS)

    for (day, slot), rooms in schedule.items():
        cell_entries = []
        for room, (batch, subject) in rooms.items():
            cell_entries.append(f"{batch.name} - {subject.name} ({room})")
        df.at[day, slot] = "\n".join(cell_entries)

    return df.fillna("")
