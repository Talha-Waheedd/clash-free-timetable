
import json
from models import Room, Teacher, Subject, Batch

class DataManager:
    def __init__(self):
        self.rooms = []
        self.teachers = []
        self.batches = []

    def to_dict(self):
        return {
            "rooms": [vars(r) for r in self.rooms],
            "teachers": [t.name for t in self.teachers],
            "batches": [
                {
                    "name": b.name,
                    "strength": b.strength,
                    "subjects": [{
                        "name": s.name,
                        "teacher": s.teacher.name,
                        "hours_per_week": s.hours_per_week,
                        "requires_lab": s.requires_lab
                    } for s in b.subjects]
                } for b in self.batches
            ]
        }

    def save(self, filename="data.json"):
        with open(filename, "w") as f:
            json.dump(self.to_dict(), f, indent=4)

    def load(self, filename="data.json"):
        with open(filename, "r") as f:
            data = json.load(f)
            self.rooms = [Room(**r) for r in data["rooms"]]
            self.teachers = [Teacher(name) for name in data["teachers"]]

            self.batches = []
            for b in data["batches"]:
                batch = Batch(b["name"], b["strength"])
                for s in b["subjects"]:
                    teacher = next((t for t in self.teachers if t.name == s["teacher"]), None)
                    if teacher:
                        subject = Subject(s["name"], teacher, s["hours_per_week"], s["requires_lab"])
                        batch.add_subject(subject)
                self.batches.append(batch)
