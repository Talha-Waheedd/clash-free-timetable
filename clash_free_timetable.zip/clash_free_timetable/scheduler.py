
import random
from schedule_config import generate_all_slots

class TimetableScheduler:
    def __init__(self, data_manager):
        self.dm = data_manager
        self.schedule = {}

    def is_slot_free(self, day, time, teacher, room):
        for r in self.dm.rooms:
            if self.schedule.get((day, time), {}).get(r.name):
                assigned = self.schedule[(day, time)][r.name]
                if r.name == room.name or assigned[1].teacher.name == teacher.name:
                    return False
        return True

    def create_schedule(self):
        slots = generate_all_slots()
        random.shuffle(slots)

        for batch in self.dm.batches:
            for subject in batch.subjects:
                needed_slots = subject.hours_per_week
                assigned = 0

                for day, time in slots:
                    for room in self.dm.rooms:
                        if subject.requires_lab and not room.is_lab:
                            continue
                        if room.capacity < batch.strength:
                            continue
                        if self.is_slot_free(day, time, subject.teacher, room):
                            self.schedule.setdefault((day, time), {})[room.name] = (batch, subject)
                            assigned += 1
                            break
                    if assigned >= needed_slots:
                        break

                if assigned < needed_slots:
                    print(f"⚠️ Warning: Could not assign all slots for {batch.name} - {subject.name}")
