
class Room:
    def __init__(self, name, capacity, is_lab=False):
        self.name = name
        self.capacity = capacity
        self.is_lab = is_lab

class Teacher:
    def __init__(self, name):
        self.name = name

class Subject:
    def __init__(self, name, teacher, hours_per_week, requires_lab=False):
        self.name = name
        self.teacher = teacher
        self.hours_per_week = hours_per_week
        self.requires_lab = requires_lab

class Batch:
    def __init__(self, name, strength):
        self.name = name
        self.strength = strength
        self.subjects = []

    def add_subject(self, subject):
        self.subjects.append(subject)
